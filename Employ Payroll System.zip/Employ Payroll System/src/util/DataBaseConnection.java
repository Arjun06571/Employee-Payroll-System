package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DataBaseConnection {

    // mysql configiration

    private static final String url = "jdbc:mysql://localhost:3306/payroll_system";
    private static final String user = "root";
    private static final String password = "Icon@0987";
    private static Connection connection = null;

    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                // Load mysql jdbc driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(url, user, password);
            }
        } catch (ClassNotFoundException e) {
            System.err.print(" ❌ Mysql JDBC Driver not Found ??");
            e.printStackTrace();
        } catch (SQLException e) {
            System.err.print("Database Connection faild ");
            e.printStackTrace();
        }
        return connection;

    }

    public static void closeconnection() {
        try {
            if (connection != null || !connection.isClosed()) {
                connection.close();
                System.out.println(" database connection closed ok ");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
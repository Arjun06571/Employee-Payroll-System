package model;

public class SalaryComponent {

    private int componentId;
    private int empId;
    private String componentType;
    private String componentName;
    private double amount;
    private String isPercentage;

    //Constructor


    public SalaryComponent() {
    }

    public SalaryComponent(int empId, String componentType, String componentName, double amount, String isPercentage) {
        this.empId = empId;
        this.componentType = componentType;
        this.componentName = componentName;
        this.amount = amount;
        this.isPercentage = isPercentage;
    }

    // getter and setter

    public int getComponentId() {
        return componentId;
    }

    public void setComponentId(int componentId) {
        this.componentId = componentId;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getComponentType() {
        return componentType;
    }

    public void setComponentType(String componentType) {
        this.componentType = componentType;
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getIsPercentage() {
        return isPercentage;
    }

    public void setIsPercentage(String isPercentage) {
        this.isPercentage = isPercentage;
    }

    @Override
    public String toString() {
        return "SalaryComponent{" +
                "isPercentage='" + isPercentage + '\'' +
                ", amount=" + amount +
                ", componentName='" + componentName + '\'' +
                ", componentType='" + componentType + '\'' +
                '}';
    }
}

package model;

import java.util.Date;

public class Employee
{
        private int empId;
        private String name;
        private String email;
        private String phone;
        private String address;
        private Date hireDate;
        private String jobtitle;
        private double basicSalary;
        private int deptId;
        private String bankAccount;
        private String status;

        //  Constructors


        public Employee() {}

        public Employee(String name, String email, String phone, String address, String jobtitle, double basicSalary, int deptId, String bankAccount) {
            this.name = name;
            this.email = email;
            this.phone = phone;
            this.address = address;
            this.jobtitle = jobtitle;
            this.basicSalary = basicSalary;
            this.deptId = deptId;
            this.bankAccount = bankAccount;
        }

        public int getEmpId() {
            return empId;
        }

        public void setEmpId(int empId) {
            this.empId = empId;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public double getBasicSalary() {
            return basicSalary;
        }

        public void setBasicSalary(double basicSalary) {
            this.basicSalary = basicSalary;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getBankAccount() {
            return bankAccount;
        }

        public void setBankAccount(String bankAccount) {
            this.bankAccount = bankAccount;
        }

        public int getDeptId() {
            return deptId;
        }

        public void setDeptId(int deptId) {
            this.deptId = deptId;
        }

        public String getJobtitle() {
            return jobtitle;
        }

        public void setJobtitle(String jobtitle) {
            this.jobtitle = jobtitle;
        }

        public Date getHireDate() {
            return hireDate;
        }

        public void setHireDate(Date hireDate) {
            this.hireDate = hireDate;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        @Override
        public String toString() {
            return "Employee{" +
                    "empId=" + empId +
                    ", name='" + name + '\'' +
                    ", email='" + email + '\'' +
                    ", jobtitle='" + jobtitle + '\'' +
                    ", basicSalary=" + basicSalary +
                    '}';
        }
    }

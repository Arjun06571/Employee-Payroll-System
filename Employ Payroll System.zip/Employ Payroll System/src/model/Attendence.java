package model;

import java.util.Date;

public class Attendence {

    private int attendanceId;
    private int empId;
    private Date attendanceDate;
    private String status;
    private double hoursWorked;
    private double overtimeHours;

    //constructor


    public Attendence() {
    }

    public Attendence(int empId, String status, double hoursWorked, double overtimeHours) {
        this.empId = empId;
        this.status = status;
        this.hoursWorked = hoursWorked;
        this.overtimeHours = overtimeHours;
    }

    public int getAttendanceId() {
        return attendanceId;
    }

    public void setAttendanceId(int attendanceId) {
        this.attendanceId = attendanceId;
    }

    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public Date getAttendanceDate() {
        return attendanceDate;
    }

    public void setAttendanceDate(Date attendanceDate) {
        this.attendanceDate = attendanceDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getOvertimeHours() {
        return overtimeHours;
    }

    public void setOvertimeHours(double overtimeHours) {
        this.overtimeHours = overtimeHours;
    }

    @Override
    public String toString() {
        return "Attendence{" +
                "attendanceId=" + attendanceId +
                ", empId=" + empId +
                ", attendanceDate=" + attendanceDate +
                ", status='" + status + '\'' +
                ", hoursWorked=" + hoursWorked +
                ", overtimeHours=" + overtimeHours +
                '}';
    }
}

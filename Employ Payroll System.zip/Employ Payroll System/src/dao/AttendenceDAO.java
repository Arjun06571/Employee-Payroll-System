package dao;

import model.Attendence;
import java.util.List;
import java.util.Date;

import java.util.Date;
import java.util.List;

public interface AttendenceDAO
{
    //create
    boolean addAttendance(Attendence attendance);

    // Read
    List<Attendence> getAttendanceByEmployee(int empId);
    List<Attendence> getAttendanceByDateRange(int empId, Date starDate, Date endDate);
    int getPresentDays(int empId, Date startDate, Date endDate);
    int getAbsentDays(int empId, Date startDate, Date endDate);
    double getTotalOvertimeHours(int empId, Date startDate, Date endDate);

    //update
    boolean updateAttendance(Attendence attendence);

    // delete
    boolean deleteAttendance(int attendanceId);
}

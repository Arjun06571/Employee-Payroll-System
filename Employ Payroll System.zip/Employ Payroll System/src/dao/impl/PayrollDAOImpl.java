package dao.impl;

import dao.PayrollDAO;
import model.Payroll;
import util.DataBaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class PayrollDAOImpl implements PayrollDAO {

    @Override
    public boolean addPayroll(Payroll payroll) {
        String sql = "INSERT INTO payroll (emp_id, pay_period_start, pay_period_end, basic_salary, allowances, deductions, overtime_pay, net_salary, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, payroll.getEmpId());
            pstmt.setDate(2, new java.sql.Date(payroll.getPayPeriodStart().getTime()));
            pstmt.setDate(3, new java.sql.Date(payroll.getPayPeriodEnd().getTime()));
            pstmt.setDouble(4, payroll.getBasicSalary());
            pstmt.setDouble(5, payroll.getAllowances());
            pstmt.setDouble(6, payroll.getDeductions());
            pstmt.setDouble(7, payroll.getOverTimePay());
            pstmt.setDouble(8, payroll.getNetSalary());
            pstmt.setString(9, payroll.getStatus());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error adding payroll: " + e.getMessage());
            return false;
        }
    }

    @Override
    public Payroll getPayrollById(int payrollId) {
        String sql = "SELECT * FROM payroll WHERE payroll_id = ?";
        Payroll payroll = null;

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, payrollId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                payroll = new Payroll();
                payroll.setPayrollId(rs.getInt("payroll_id"));
                payroll.setEmpId(rs.getInt("emp_id"));
                payroll.setPayPeriodStart(rs.getDate("pay_period_start"));
                payroll.setPayPeriodEnd(rs.getDate("pay_period_end"));
                payroll.setBasicSalary(rs.getDouble("basic_salary"));
                payroll.setAllowances(rs.getDouble("allowances"));
                payroll.setDeductions(rs.getDouble("deductions"));
                payroll.setOverTimePay(rs.getDouble("overtime_pay"));
                payroll.setNetSalary(rs.getDouble("net_salary"));
                payroll.setGenratedDate(rs.getDate("generated_date"));
                payroll.setStatus(rs.getString("status"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting payroll by ID: " + e.getMessage());
        }

        return payroll;
    }

    @Override
    public List<Payroll> getPayrollByEmployee(int empId) {
        List<Payroll> payrollList = new ArrayList<>();
        String sql = "SELECT * FROM payroll WHERE emp_id = ? ORDER BY pay_period_start DESC";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Payroll payroll = new Payroll();
                payroll.setPayrollId(rs.getInt("payroll_id"));
                payroll.setEmpId(rs.getInt("emp_id"));
                payroll.setPayPeriodStart(rs.getDate("pay_period_start"));
                payroll.setPayPeriodEnd(rs.getDate("pay_period_end"));
                payroll.setBasicSalary(rs.getDouble("basic_salary"));
                payroll.setAllowances(rs.getDouble("allowances"));
                payroll.setDeductions(rs.getDouble("deductions"));
                payroll.setOverTimePay(rs.getDouble("overtime_pay"));
                payroll.setNetSalary(rs.getDouble("net_salary"));
                payroll.setGenratedDate(rs.getDate("generated_date"));
                payroll.setStatus(rs.getString("status"));

                payrollList.add(payroll);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting payroll by employee: " + e.getMessage());
        }

        return payrollList;
    }

    @Override
    public List<Payroll> getPayrollByDateRange(Date startDate, Date endDate) {
        List<Payroll> payrollList = new ArrayList<>();
        String sql = "SELECT * FROM payroll WHERE pay_period_start >= ? AND pay_period_end <= ? ORDER BY pay_period_start";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDate(1, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(2, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Payroll payroll = new Payroll();
                payroll.setPayrollId(rs.getInt("payroll_id"));
                payroll.setEmpId(rs.getInt("emp_id"));
                payroll.setPayPeriodStart(rs.getDate("pay_period_start"));
                payroll.setPayPeriodEnd(rs.getDate("pay_period_end"));
                payroll.setBasicSalary(rs.getDouble("basic_salary"));
                payroll.setAllowances(rs.getDouble("allowances"));
                payroll.setDeductions(rs.getDouble("deductions"));
                payroll.setOverTimePay(rs.getDouble("overtime_pay"));
                payroll.setNetSalary(rs.getDouble("net_salary"));
                payroll.setGenratedDate(rs.getDate("generated_date"));
                payroll.setStatus(rs.getString("status"));

                payrollList.add(payroll);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting payroll by date range: " + e.getMessage());
        }

        return payrollList;
    }

    @Override
    public Payroll getPayrollByEmployeeAndPeriod(int empId, Date startDate, Date endDate) {
        String sql = "SELECT * FROM payroll WHERE emp_id = ? AND pay_period_start = ? AND pay_period_end = ?";
        Payroll payroll = null;

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            pstmt.setDate(2, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                payroll = new Payroll();
                payroll.setPayrollId(rs.getInt("payroll_id"));
                payroll.setEmpId(rs.getInt("emp_id"));
                payroll.setPayPeriodStart(rs.getDate("pay_period_start"));
                payroll.setPayPeriodEnd(rs.getDate("pay_period_end"));
                payroll.setBasicSalary(rs.getDouble("basic_salary"));
                payroll.setAllowances(rs.getDouble("allowances"));
                payroll.setDeductions(rs.getDouble("deductions"));
                payroll.setOverTimePay(rs.getDouble("overtime_pay"));
                payroll.setNetSalary(rs.getDouble("net_salary"));
                payroll.setGenratedDate(rs.getDate("generated_date"));
                payroll.setStatus(rs.getString("status"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting payroll by employee and period: " + e.getMessage());
        }

        return payroll;
    }

    @Override
    public boolean updatePayroll(Payroll payroll) {
        String sql = "UPDATE payroll SET allowances = ?, deductions = ?, overtime_pay = ?, net_salary = ?, status = ? WHERE payroll_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDouble(1, payroll.getAllowances());
            pstmt.setDouble(2, payroll.getDeductions());
            pstmt.setDouble(3, payroll.getOverTimePay());
            pstmt.setDouble(4, payroll.getNetSalary());
            pstmt.setString(5, payroll.getStatus());
            pstmt.setInt(6, payroll.getPayrollId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating payroll: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean updatePayrollStatus(int payrollId, String status) {
        String sql = "UPDATE payroll SET status = ? WHERE payroll_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, status);
            pstmt.setInt(2, payrollId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating payroll status: " + e.getMessage());
            return false;
        }
    }

    @Override
    public double getTotalSalaryExpenditure(Date startDate, Date endDate) {
        String sql = "SELECT COALESCE(SUM(net_salary), 0) FROM payroll WHERE pay_period_start >= ? AND pay_period_end <= ? AND status = 'PAID'";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setDate(1, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(2, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting total salary expenditure: " + e.getMessage());
        }

        return 0;
    }
}
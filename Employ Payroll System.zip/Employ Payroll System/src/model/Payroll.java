package model;

import java.util.Date;

public class Payroll {

    private int payrollId;
    private int empId;
    private Date payPeriodStart;
    private Date payPeriodEnd;
    private double basicSalary;
    private double allowances;
    private double deductions;
    private double OverTimePay;
    private double netSalary;
    private Date genratedDate;
    private String status;

    // constructor


    public Payroll() {
    }

    public Payroll(int empId, Date payPeriodStart, Date payPeriodEnd, double basicSalary) {
        this.empId = empId;
        this.payPeriodStart = payPeriodStart;
        this.payPeriodEnd = payPeriodEnd;
        this.basicSalary = basicSalary;
    }

    public int getPayrollId() {
        return payrollId;
    }

    public void setPayrollId(int payrollId) {
        this.payrollId = payrollId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getNetSalary() {
        return netSalary;
    }

    public void setNetSalary(double netSalary) {
        this.netSalary = netSalary;
    }

    public double getOverTimePay() {
        return OverTimePay;
    }

    public void setOverTimePay(double overTimePay) {
        OverTimePay = overTimePay;
    }

    public double getDeductions() {
        return deductions;
    }

    public void setDeductions(double deductions) {
        this.deductions = deductions;
    }

    public double getBasicSalary() {
        return basicSalary;
    }

    public void setBasicSalary(double basicSalary) {
        this.basicSalary = basicSalary;
    }

    public Date getPayPeriodEnd() {
        return payPeriodEnd;
    }

    public void setPayPeriodEnd(Date payPeriodEnd) {
        this.payPeriodEnd = payPeriodEnd;
    }

    public Date getPayPeriodStart() {
        return payPeriodStart;
    }

    public void setPayPeriodStart(Date payPeriodStart) {
        this.payPeriodStart = payPeriodStart;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public double getAllowances() {
        return allowances;
    }

    public void setAllowances(double allowances) {
        this.allowances = allowances;
    }

    public Date getGenratedDate() {
        return genratedDate;
    }

    public void setGenratedDate(Date genratedDate) {
        this.genratedDate = genratedDate;
    }

    @Override
    public String toString() {
        return "Payroll{" +
                "payrollId=" + payrollId +
                ", empId=" + empId +
                ", payPeriodStart=" + payPeriodStart +
                ", payPeriodEnd=" + payPeriodEnd +
                ", netSalary=" + netSalary +
                '}';
    }
}

package dao;

import model.Department;
import java.util.List;

  public interface DepartmentDAO
  {

      //Create
      boolean addDepartment(Department department);

      //Read
      Department getDepartmentById(int deptId);
      List<Department> getAllDepartment();

      //Update
      boolean updateDepartment(Department department);
      boolean updateDepartmentManager(int deptId, int managerId);

      //Delete
      boolean deleteDepartment(int deptId);

      //Validation
      boolean departmentExists(int deptId);
  }

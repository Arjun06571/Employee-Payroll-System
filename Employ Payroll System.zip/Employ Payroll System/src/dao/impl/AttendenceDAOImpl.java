package dao.impl;

import dao.AttendenceDAO;
import model.Attendence;
import util.DataBaseConnection;

import javax.xml.crypto.Data;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;

public class AttendenceDAOImpl implements AttendenceDAO {
    @Override
    public boolean addAttendance(Attendence attendance)
    {
        String sql = "insert into Attendence (emp_id, status, hours_worked, overtime_hours) values (?,?,?,?)";

        try (Connection connection = DataBaseConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement(sql))
        {

            ps.setInt(1,attendance.getEmpId());
            ps.setString(2, attendance.getStatus());
            ps.setDouble(3,attendance.getHoursWorked());
            ps.setDouble(4,attendance.getOvertimeHours());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected >0;
        }
        catch (SQLException e )
        {
            System.err.print("error adding attendence:-" + e.getMessage());
          return false;
        }
    }



    @Override
    public List<Attendence> getAttendanceByEmployee(int empId) {
        List<Attendence> attendenceList = new ArrayList<>();
        String sql = "select * from attendance where emp_id = ? order by attendance_date DESC";

        try (Connection connection = DataBaseConnection.getConnection();
        PreparedStatement ps= connection.prepareStatement(sql)) {

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Attendence attendence = new Attendence();
                attendence.setAttendanceId(rs.getInt("attendence_id"));
                attendence.setEmpId(rs.getInt("emp_id"));
                attendence.setAttendanceDate(rs.getDate("attendance_date"));
                attendence.setStatus(rs.getString("status"));
                attendence.setHoursWorked(rs.getDouble("hours_worked"));
                attendence.setOvertimeHours(rs.getDouble("overtime_hours"));

                attendenceList.add(attendence);
            }
        } catch (SQLException e)
        {
            System.err.print("Error getting by employee:-"+ e.getMessage());
        }
        return attendenceList;
    }


    @Override
    public List<Attendence> getAttendanceByDateRange(int empId, Date starDate, Date endDate) {
        List<Attendence> attendenceList = new ArrayList<>();
        String sql = "select * from attendance where emp_id = ? and attendance_date between ? and ? order by attendance_date";

        try (Connection connection=DataBaseConnection.getConnection();
        PreparedStatement ps= connection.prepareStatement(sql)) {

            ps.setInt(1,empId);
            ps.setDate(2, new java.sql.Date(starDate.getTime()));
            ps.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs= ps.executeQuery();

            while (rs.next()) {
                Attendence attendence =  new Attendence();
                attendence.setAttendanceId(rs.getInt("attendance_id"));
                attendence.setEmpId(rs.getInt("emp_id"));
                attendence.setAttendanceDate(rs.getDate("attendance_date"));
                attendence.setStatus(rs.getString("status"));
                attendence.setHoursWorked(rs.getDouble("hours_worked"));
                attendence.setOvertimeHours(rs.getDouble("overtime_hours"));

                attendenceList.add(attendence);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting attendance by date range: " + e.getMessage());
        }

        return attendenceList;
    }


    @Override
    public int getPresentDays(int empId, Date startDate, Date endDate) {
        String sql = "SELECT COUNT(*) FROM attendance WHERE emp_id = ? AND attendance_date BETWEEN ? AND ? AND status = 'PRESENT'";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            pstmt.setDate(2, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting present days: " + e.getMessage());
        }

        return 0;
    }

    @Override
    public int getAbsentDays(int empId, Date startDate, Date endDate) {
        String sql = "SELECT COUNT(*) FROM attendance WHERE emp_id = ? AND attendance_date BETWEEN ? AND ? AND status = 'ABSENT'";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            pstmt.setDate(2, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting absent days: " + e.getMessage());
        }

        return 0;
    }


    @Override
    public double getTotalOvertimeHours(int empId, Date startDate, Date endDate) {
        String sql = "SELECT COALESCE(SUM(overtime_hours), 0) FROM attendance WHERE emp_id = ? AND attendance_date BETWEEN ? AND ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            pstmt.setDate(2, new java.sql.Date(startDate.getTime()));
            pstmt.setDate(3, new java.sql.Date(endDate.getTime()));

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getDouble(1);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting total overtime hours: " + e.getMessage());
        }

        return 0;
    }

    @Override
    public boolean updateAttendance(Attendence attendence) {
        String sql = "UPDATE attendance SET status = ?, hours_worked = ?, overtime_hours = ? WHERE attendance_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, attendence.getStatus());
            pstmt.setDouble(2, attendence.getHoursWorked());
            pstmt.setDouble(3, attendence.getOvertimeHours());
            pstmt.setInt(4, attendence.getAttendanceId());

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating attendance: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteAttendance(int attendanceId) {
        String sql = "DELETE FROM attendance WHERE attendance_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, attendanceId);
            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error deleting attendance: " + e.getMessage());
            return false;
        }
    }
}


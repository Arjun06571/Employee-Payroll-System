package dao.impl;

import dao.DepartmentDAO;
import model.Department;
import util.DataBaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDAOImpl implements DepartmentDAO
{

    @Override
    public boolean addDepartment(Department department) {
        String sql = "insert into departments (dept_id, manager_id) values (?,?)";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, department.getDeptName());
            if (department.getManagerId() != null) {
                ps.setInt(2, department.getManagerId());
            } else {
                ps.setNull(2, Types.INTEGER);
            }

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.print("Error ading department:- " + e.getMessage());
            return false;
        }
    }

    @Override
    public Department getDepartmentById(int deptId) {
        String sql = "select * from departments where dept_id = ?";
        Department department = null;

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, deptId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                department = new Department();
                department.setDeptId(rs.getInt("dept_id"));
                department.setDeptName(rs.getString("dept_name"));
                department.setManagerId(rs.getInt("manager_id"));

                if (rs.wasNull()) {
                    department.setManagerId(null);
                }
            }
        } catch (SQLException e) {
            System.err.print("error geting department :-" + e.getMessage());
        }
        return null;
    }


    @Override
    public List<Department> getAllDepartment() {
        List<Department> departments = new ArrayList<>();
        String sql = "select * from departments order by dept_id";

        try (Connection connection = DataBaseConnection.getConnection();
             Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Department department = new Department();
                department.setDeptId(rs.getInt("dept_id"));
                department.setDeptName(rs.getString("dept_name"));
                department.setManagerId(rs.getInt("manager_id"));

                if (rs.wasNull()) {
                    department.setManagerId(null);
                }
            }
        } catch (SQLException e) {
            System.err.print(" Error geting all department :- " + e.getMessage());
        }
        return departments;
    }

    @Override
    public boolean updateDepartment(Department department) {
        String sql = "UPDATE departments set dept_id = ?, manager_id= ?, WHERE dept_id = ?";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1, department.getDeptName());
            if (department.getManagerId() != null) {
                ps.setInt(2, department.getManagerId());
            } else {
                ps.setNull(2, Types.INTEGER);
            }
            ps.setInt(3, department.getDeptId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.print("Error updating department:- " + e.getMessage());
            return false;
        }
    }


    @Override
    public boolean updateDepartmentManager(int deptId, int managerId) {
        String sql = "UPDATE departments SET manager_id = ? WHERE dept_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, managerId);
            pstmt.setInt(2, deptId);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating department manager: " + e.getMessage());
            return false;
        }
    }


    @Override
    public boolean deleteDepartment(int deptId) {

        String checksql = "select count(*) from employees where dept_id = ?";
        String deletesql = "delete from departments where dept_id = ?";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement checkps = connection.prepareStatement(checksql);
             PreparedStatement deleteps = connection.prepareStatement(deletesql)) {

            checkps.setInt(1, deptId);
            ResultSet rs = checkps.executeQuery();

            if (rs.next() && rs.getInt(1) > 0) {
                System.out.print("Cannot delete department with existing employee" );

                return false;
            }

            deleteps.setInt(1, deptId);
            int rowsAffected = deleteps.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.err.print("error deleting department :-" + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean departmentExists(int deptId) {
        String sql = "SELECT 1 FROM departments WHERE dept_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, deptId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            System.err.println("❌ Error checking department existence: " + e.getMessage());
            return false;
        }
    }
}
package Service;

import dao.EmployeeDAO;
import dao.DepartmentDAO;
import dao.impl.EmployeeDAOImpl;
import dao.impl.DepartmentDAOImpl;
import model.Employee;
import model.Department;

import java.util.List;

public class EmployeeService {
    private EmployeeDAO employeeDAO;
    private DepartmentDAO departmentDAO;

    public EmployeeService() {
        this.employeeDAO = new EmployeeDAOImpl();
        this.departmentDAO = new DepartmentDAOImpl();
    }

    public boolean registerEmployee(String name, String email, String phone, String address,
                                    String jobTitle, double basicSalary, int deptId, String bankAccount) {
        // Validation
        if (name == null || name.trim().isEmpty()) {
            System.out.println("❌ Error: Name cannot be empty!");
            return false;
        }

        if (email == null || !email.contains("@")) {
            System.out.println("❌ Error: Invalid email format!");
            return false;
        }

        if (basicSalary <= 0) {
            System.out.println("❌ Error: Basic salary must be positive!");
            return false;
        }

        // Check if email already exists
        if (employeeDAO.getEmployeeByEmail(email) != null) {
            System.out.println("❌ Error: Email already registered!");
            return false;
        }

        // Check if department exists
        if (!departmentDAO.departmentExists(deptId)) {
            System.out.println("❌ Error: Department does not exist!");
            return false;
        }

        Employee employee = new Employee(name, email, phone, address, jobTitle, basicSalary, deptId, bankAccount);
        boolean success = employeeDAO.addEmployee(employee);

        if (success) {
            System.out.println("✅ Employee registered successfully!");
        } else {
            System.out.println("❌ Failed to register employee!");
        }

        return success;
    }

    public Employee getEmployee(int empId) {
        Employee employee = employeeDAO.getEmployeeByID(empId);
        if (employee == null) {
            System.out.println("❌ Employee not found with ID: " + empId);
        }
        return employee;
    }

    public Employee getEmployeeByEmail(String email) {
        return employeeDAO.getEmployeeByEmail(email);
    }

    public List<Employee> getAllEmployees() {
        return employeeDAO.getAllEmployee();
    }

    public List<Employee> getEmployeesByDepartment(int deptId) {
        return employeeDAO.getEmployeeByDepartment(deptId);
    }

    public boolean updateEmployee(int empId, String name, String phone, String address,
                                  String jobTitle, int deptId, String bankAccount) {
        Employee employee = employeeDAO.getEmployeeByID(empId);
        if (employee == null) {
            System.out.println("❌ Employee not found!");
            return false;
        }

        employee.setName(name);
        employee.setPhone(phone);
        employee.setAddress(address);
        employee.setJobtitle(jobTitle);
        employee.setDeptId(deptId);
        employee.setBankAccount(bankAccount);

        boolean success = employeeDAO.updateEmployee(employee);
        if (success) {
            System.out.println("✅ Employee updated successfully!");
        } else {
            System.out.println("❌ Failed to update employee!");
        }

        return success;
    }

    public boolean updateEmployeeSalary(int empId, double newSalary) {
        if (newSalary <= 0) {
            System.out.println("❌ Error: Salary must be positive!");
            return false;
        }

        boolean success = employeeDAO.updateEmployeeSalary(empId, newSalary);
        if (success) {
            System.out.println("✅ Employee salary updated successfully!");
        } else {
            System.out.println("❌ Failed to update employee salary!");
        }

        return success;
    }

    public boolean deleteEmployee (int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Employee not found!");
            return false;
        }

        boolean success = employeeDAO.deleteEmployee(empId);
        if (success) {
            System.out.println("✅ Employee marked as inactive!");
        } else {
            System.out.println("❌ Failed to delete employee!");
        }

        return success;
    }

    public void printEmployeeDetails(Employee employee) {
        if (employee != null) {
            System.out.println("\n📋 EMPLOYEE DETAILS:");
            System.out.println("┌─────────────────────────────────────────────────────");
            System.out.println("│ ID: " + employee.getEmpId());
            System.out.println("│ Name: " + employee.getName());
            System.out.println("│ Email: " + employee.getEmail());
            System.out.println("│ Phone: " + employee.getPhone());
            System.out.println("│ Address: " + employee.getAddress());
            System.out.println("│ Job Title: " + employee.getJobtitle());
            System.out.println("│ Basic Salary: ₹" + employee.getBasicSalary());
            System.out.println("│ Department ID: " + employee.getDeptId());
            System.out.println("│ Bank Account: " + employee.getBankAccount());
            System.out.println("│ Status: " + employee.getStatus());
            System.out.println("│ Hire Date: " + employee.getHireDate());
            System.out.println("└─────────────────────────────────────────────────────");
        }
    }
}
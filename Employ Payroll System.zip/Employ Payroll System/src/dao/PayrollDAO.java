package dao;

import model.Payroll;
import java.util.List;
import java.util.Date;

public interface PayrollDAO
{
  // create
    boolean addPayroll(Payroll payroll);

    // Read
    Payroll getPayrollById(int payrollId);
    List<Payroll> getPayrollByEmployee(int empId);
    List<Payroll> getPayrollByDateRange(Date startDate, Date endDate);
    Payroll getPayrollByEmployeeAndPeriod (int empId,Date startDate, Date endDate);

    // Update
    boolean updatePayroll(Payroll payroll);
    boolean updatePayrollStatus(int payrollId, String status);

    //Report
    double getTotalSalaryExpenditure(Date startDate, Date endDate);
}

package model;

public class Department {
    private int deptId;
    private String deptName;
    private Integer managerId;

    //constructor


    public Department() {
    }

    public Department(String deptName, Integer managerId) {
        this.deptName = deptName;
        this.managerId = managerId;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Integer getManagerId() {
        return managerId;
    }

    public void setManagerId(Integer managerId) {
        this.managerId = managerId;
    }

    @Override
    public String toString() {
        return "Department{" +
                "deptId=" + deptId +
                ", deptName='" + deptName + '\'' +
                ", managerId=" + managerId +
                '}';
    }
}

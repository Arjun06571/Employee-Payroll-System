package main;

import Service.*;
import model.*;

import java.util.*;
import java.text.SimpleDateFormat;
import java.text.ParseException;

public class PayrollApplication {
    private static EmployeeService employeeService = new EmployeeService();
    private static DepartmentService departmentService = new DepartmentService();
    private static AttendanceService attendanceService = new AttendanceService();
    private static SalaryService salaryService = new SalaryService();
    private static PayrollService payrollService = new PayrollService();
    private static Scanner scanner = new Scanner(System.in);
    private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static void main(String[] args) {
        System.out.println("================================================");
        System.out.println("        EMPLOYEE PAYROLL SYSTEM           ");
        System.out.println("================================================");
        System.out.println("         Efficient • Accurate • Secure          ");
        System.out.println("================================================");

        showMainMenu();
    }

    private static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
    }

    private static void showMainMenu() {
        while (true) {
            System.out.println("\n=== MAIN MENU ===");
            System.out.println("1. Employee Management");
            System.out.println("2. Department Management");
            System.out.println("3. Attendance Management");
            System.out.println("4. Salary Management");
            System.out.println("5. Payroll Processing");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    showEmployeeMenu();
                    break;
                case 2:
                    showDepartmentMenu();
                    break;
                case 3:
                    showAttendanceMenu();
                    break;
                case 4:
                    showSalaryMenu();
                    break;
                case 5:
                    showPayrollMenu();
                    break;
                case 6:
                    System.out.println("\nThank you for using Employee Payroll System!");
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showEmployeeMenu() {
        while (true) {
            System.out.println("\n=== EMPLOYEE MANAGEMENT ===");
            System.out.println("1. Register New Employee");
            System.out.println("2. View All Employees");
            System.out.println("3. Search Employee by ID");
            System.out.println("4. Update Employee");
            System.out.println("5. Update Salary");
            System.out.println("6. Delete Employee");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    registerEmployee();
                    break;
                case 2:
                    viewAllEmployees();
                    break;
                case 3:
                    searchEmployeeById();
                    break;
                case 4:
                    updateEmployee();
                    break;
                case 5:
                    updateEmployeeSalary();
                    break;
                case 6:
                    deleteEmployee();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showDepartmentMenu() {
        while (true) {
            System.out.println("\n=== DEPARTMENT MANAGEMENT ===");
            System.out.println("1. Create Department");
            System.out.println("2. View All Departments");
            System.out.println("3. View Department Employees");
            System.out.println("4. Update Department");
            System.out.println("5. Update Manager");
            System.out.println("6. Delete Department");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    createDepartment();
                    break;
                case 2:
                    viewAllDepartments();
                    break;
                case 3:
                    viewDepartmentEmployees();
                    break;
                case 4:
                    updateDepartment();
                    break;
                case 5:
                    updateDepartmentManager();
                    break;
                case 6:
                    deleteDepartment();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showAttendanceMenu() {
        while (true) {
            System.out.println("\n=== ATTENDANCE MANAGEMENT ===");
            System.out.println("1. Mark Attendance");
            System.out.println("2. View Employee Attendance");
            System.out.println("3. Attendance Summary");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    markAttendance();
                    break;
                case 2:
                    viewEmployeeAttendance();
                    break;
                case 3:
                    viewAttendanceSummary();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showSalaryMenu() {
        while (true) {
            System.out.println("\n=== SALARY MANAGEMENT ===");
            System.out.println("1. Add Salary Component");
            System.out.println("2. View Salary Components");
            System.out.println("3. Calculate Salary");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    addSalaryComponent();
                    break;
                case 2:
                    viewSalaryComponents();
                    break;
                case 3:
                    calculateSalary();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    private static void showPayrollMenu() {
        while (true) {
            System.out.println("\n=== PAYROLL PROCESSING ===");
            System.out.println("1. Generate Payroll (Single Employee)");
            System.out.println("2. Generate Bulk Payroll (All Employees)");
            System.out.println("3. View Employee Payroll");
            System.out.println("4. Payroll Summary Report");
            System.out.println("5. Mark Payroll as Paid");
            System.out.println("6. Total Salary Expenditure");
            System.out.println("7. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    generatePayrollSingle();
                    break;
                case 2:
                    generateBulkPayroll();
                    break;
                case 3:
                    viewEmployeePayroll();
                    break;
                case 4:
                    viewPayrollSummary();
                    break;
                case 5:
                    markPayrollAsPaid();
                    break;
                case 6:
                    viewSalaryExpenditure();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid option! Please try again.");
            }
        }
    }

    // ==================== EMPLOYEE MANAGEMENT METHODS ====================

    private static void registerEmployee() {
        System.out.println("\n=== REGISTER NEW EMPLOYEE ===");

        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Email: ");
        String email = scanner.nextLine();

        System.out.print("Phone: ");
        String phone = scanner.nextLine();

        System.out.print("Address: ");
        String address = scanner.nextLine();

        System.out.print("Job Title: ");
        String jobTitle = scanner.nextLine();

        System.out.print("Basic Salary: ");
        double basicSalary = getDoubleInput();

        System.out.print("Department ID: ");
        int deptId = getIntInput();

        System.out.print("Bank Account: ");
        String bankAccount = scanner.nextLine();

        employeeService.registerEmployee(name, email, phone, address, jobTitle, basicSalary, deptId, bankAccount);
        pressAnyKeyToContinue();
    }

    private static void viewAllEmployees() {
        System.out.println("\n=== ALL EMPLOYEES ===");
        List<Employee> employees = employeeService.getAllEmployees();

        if (employees.isEmpty()) {
            System.out.println("No employees found!");
            return;
        }

        System.out.println("ID\tName\t\tEmail\t\t\tSalary\t\tStatus");
        System.out.println("------------------------------------------------------------------------");

        for (Employee employee : employees) {
            System.out.printf("%d\t%-15s\t%-20s\t%.2f\t%s\n",
                    employee.getEmpId(),
                    employee.getName(),
                    employee.getEmail(),
                    employee.getBasicSalary(),
                    employee.getStatus()
            );
        }
        pressAnyKeyToContinue();
    }

    private static void searchEmployeeById() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        Employee employee = employeeService.getEmployee(empId);
        if (employee != null) {
            System.out.println("\nEmployee Details:");
            System.out.println("ID: " + employee.getEmpId());
            System.out.println("Name: " + employee.getName());
            System.out.println("Email: " + employee.getEmail());
            System.out.println("Phone: " + employee.getPhone());
            System.out.println("Address: " + employee.getAddress());
            System.out.println("Job Title: " + employee.getJobtitle());
            System.out.println("Salary: " + employee.getBasicSalary());
            System.out.println("Department ID: " + employee.getDeptId());
            System.out.println("Bank Account: " + employee.getBankAccount());
            System.out.println("Status: " + employee.getStatus());
        } else {
            System.out.println("Employee not found!");
        }
        pressAnyKeyToContinue();
    }

    private static void updateEmployee() {
        System.out.print("Enter Employee ID to update: ");
        int empId = getIntInput();

        Employee employee = employeeService.getEmployee(empId);
        if (employee == null) {
            System.out.println("Employee not found!");
            pressAnyKeyToContinue();
            return;
        }

        System.out.println("Current Details:");
        System.out.println("Name: " + employee.getName());
        System.out.println("Phone: " + employee.getPhone());
        System.out.println("Address: " + employee.getAddress());
        System.out.println("Job Title: " + employee.getJobtitle());
        System.out.println("Department ID: " + employee.getDeptId());
        System.out.println("Bank Account: " + employee.getBankAccount());

        System.out.println("\nEnter new details (press Enter to keep current value):");

        System.out.print("Name: ");
        String name = scanner.nextLine();
        if (name.trim().isEmpty()) name = employee.getName();

        System.out.print("Phone: ");
        String phone = scanner.nextLine();
        if (phone.trim().isEmpty()) phone = employee.getPhone();

        System.out.print("Address: ");
        String address = scanner.nextLine();
        if (address.trim().isEmpty()) address = employee.getAddress();

        System.out.print("Job Title: ");
        String jobTitle = scanner.nextLine();
        if (jobTitle.trim().isEmpty()) jobTitle = employee.getJobtitle();

        System.out.print("Department ID: ");
        String deptInput = scanner.nextLine();
        int deptId = deptInput.isEmpty() ? employee.getDeptId() : Integer.parseInt(deptInput);

        System.out.print("Bank Account: ");
        String bankAccount = scanner.nextLine();
        if (bankAccount.trim().isEmpty()) bankAccount = employee.getBankAccount();

        boolean success = employeeService.updateEmployee(empId, name, phone, address, jobTitle, deptId, bankAccount);
        if (success) {
            System.out.println("Employee updated successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void updateEmployeeSalary() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        Employee employee = employeeService.getEmployee(empId);
        if (employee == null) {
            System.out.println("Employee not found!");
            pressAnyKeyToContinue();
            return;
        }

        System.out.println("Current Salary: " + employee.getBasicSalary());
        System.out.print("Enter New Salary: ");
        double newSalary = getDoubleInput();

        boolean success = employeeService.updateEmployeeSalary(empId, newSalary);
        if (success) {
            System.out.println("Salary updated successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void deleteEmployee() {
        System.out.print("Enter Employee ID to delete: ");
        int empId = getIntInput();

        System.out.print("Are you sure you want to mark employee as inactive? (yes/no): ");
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("yes")) {
            boolean success = employeeService.deleteEmployee(empId);
            if (success) {
                System.out.println("Employee marked as inactive!");
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
        pressAnyKeyToContinue();
    }

    // ==================== DEPARTMENT MANAGEMENT METHODS ====================

    private static void createDepartment() {
        System.out.println("\n=== CREATE DEPARTMENT ===");

        System.out.print("Department Name: ");
        String deptName = scanner.nextLine();

        System.out.print("Manager ID (press Enter if none): ");
        String managerInput = scanner.nextLine();
        Integer managerId = managerInput.isEmpty() ? null : Integer.parseInt(managerInput);

        departmentService.createDepartment(deptName, managerId);
        pressAnyKeyToContinue();
    }

    private static void viewAllDepartments() {
        System.out.println("\n=== ALL DEPARTMENTS ===");
        List<Department> departments = departmentService.getAllDepartments();

        if (departments.isEmpty()) {
            System.out.println("No departments found!");
            return;
        }

        System.out.println("ID\tName\t\tManager ID");
        System.out.println("----------------------------------");

        for (Department department : departments) {
            System.out.printf("%d\t%-15s\t%s\n",
                    department.getDeptId(),
                    department.getDeptName(),
                    department.getManagerId() != null ? department.getManagerId() : "Not Assigned"
            );
        }
        pressAnyKeyToContinue();
    }

    private static void viewDepartmentEmployees() {
        System.out.print("Enter Department ID: ");
        int deptId = getIntInput();

        List<Employee> employees = employeeService.getEmployeesByDepartment(deptId);

        if (employees.isEmpty()) {
            System.out.println("No employees found in this department!");
            return;
        }

        System.out.println("\n=== EMPLOYEES IN DEPARTMENT " + deptId + " ===");
        System.out.println("ID\tName\t\tEmail\t\t\tJob Title");
        System.out.println("--------------------------------------------------------");

        for (Employee employee : employees) {
            System.out.printf("%d\t%-15s\t%-20s\t%s\n",
                    employee.getEmpId(),
                    employee.getName(),
                    employee.getEmail(),
                    employee.getJobtitle()
            );
        }
        pressAnyKeyToContinue();
    }

    private static void updateDepartment() {
        System.out.print("Enter Department ID to update: ");
        int deptId = getIntInput();

        Department department = departmentService.getDepartment(deptId);
        if (department == null) {
            System.out.println("Department not found!");
            pressAnyKeyToContinue();
            return;
        }

        System.out.println("Current Details:");
        System.out.println("Name: " + department.getDeptName());
        System.out.println("Manager ID: " + (department.getManagerId() != null ? department.getManagerId() : "Not Assigned"));

        System.out.print("New Department Name: ");
        String deptName = scanner.nextLine();
        if (deptName.trim().isEmpty()) deptName = department.getDeptName();

        System.out.print("New Manager ID (press Enter to keep current): ");
        String managerInput = scanner.nextLine();
        Integer managerId = managerInput.isEmpty() ? department.getManagerId() :
                managerInput.equalsIgnoreCase("null") ? null : Integer.parseInt(managerInput);

        boolean success = departmentService.updateDepartment(deptId, deptName, managerId);
        if (success) {
            System.out.println("Department updated successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void updateDepartmentManager() {
        System.out.print("Enter Department ID: ");
        int deptId = getIntInput();

        System.out.print("Enter New Manager Employee ID: ");
        int managerId = getIntInput();

        boolean success = departmentService.updateDepartmentManager(deptId, managerId);
        if (success) {
            System.out.println("Department manager updated successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void deleteDepartment() {
        System.out.print("Enter Department ID to delete: ");
        int deptId = getIntInput();

        System.out.print("Are you sure? This will delete the department permanently! (yes/no): ");
        String confirmation = scanner.nextLine();

        if (confirmation.equalsIgnoreCase("yes")) {
            boolean success = departmentService.deleteDepartment(deptId);
            if (success) {
                System.out.println("Department deleted successfully!");
            }
        } else {
            System.out.println("Deletion cancelled.");
        }
        pressAnyKeyToContinue();
    }

    // ==================== ATTENDANCE MANAGEMENT METHODS ====================

    private static void markAttendance() {
        System.out.println("\n=== MARK ATTENDANCE ===");

        System.out.print("Employee ID: ");
        int empId = getIntInput();

        System.out.print("Status (PRESENT/ABSENT/HALF_DAY): ");
        String status = scanner.nextLine().toUpperCase();

        System.out.print("Hours Worked (default 8.0): ");
        String hoursInput = scanner.nextLine();
        double hoursWorked = hoursInput.isEmpty() ? 8.0 : Double.parseDouble(hoursInput);

        System.out.print("Overtime Hours (default 0.0): ");
        String overtimeInput = scanner.nextLine();
        double overtimeHours = overtimeInput.isEmpty() ? 0.0 : Double.parseDouble(overtimeInput);

        boolean success = attendanceService.markAttendance(empId, status, hoursWorked, overtimeHours);
        if (success) {
            System.out.println("Attendance marked successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void viewEmployeeAttendance() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        List<Attendence> attendanceList = attendanceService.getEmployeeAttendance(empId);

        if (attendanceList == null || attendanceList.isEmpty()) {
            System.out.println("No attendance records found!");
            return;
        }

        System.out.println("\n=== ATTENDANCE RECORDS ===");
        System.out.println("Date\t\tStatus\t\tHours\tOvertime");
        System.out.println("----------------------------------------");

        for (Attendence attendence : attendanceList) {
            System.out.printf("%s\t%s\t\t%.1f\t%.1f\n",
                    dateFormat.format(attendence.getAttendanceDate()),
                    attendence.getStatus(),
                    attendence.getHoursWorked(),
                    attendence.getOvertimeHours()
            );
        }
        pressAnyKeyToContinue();
    }

    private static void viewAttendanceSummary() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        System.out.println("Enter Date Range:");
        System.out.println("Start Date:");
        Date startDate = getDateInput();
        System.out.println("End Date:");
        Date endDate = getDateInput();

        AttendanceService.AttendanceSummary summary = attendanceService.getAttendanceSummary(empId, startDate, endDate);

        if (summary != null) {
            System.out.println("\n=== ATTENDANCE SUMMARY ===");
            System.out.println("Period: " + dateFormat.format(startDate) + " to " + dateFormat.format(endDate));
            System.out.println("Present Days: " + summary.getPresentDays());
            System.out.println("Absent Days: " + summary.getAbsentDays());
            System.out.println("Total Overtime: " + summary.getTotalOvertime() + " hours");
        }
        pressAnyKeyToContinue();
    }

    // ==================== SALARY MANAGEMENT METHODS ====================

    private static void addSalaryComponent() {
        System.out.println("\n=== ADD SALARY COMPONENT ===");

        System.out.print("Employee ID: ");
        int empId = getIntInput();

        System.out.print("Component Type (ALLOWANCE/DEDUCTION): ");
        String componentType = scanner.nextLine().toUpperCase();

        System.out.print("Component Name: ");
        String componentName = scanner.nextLine();

        System.out.print("Amount: ");
        double amount = getDoubleInput();

        System.out.print("Is Percentage? (Y/N): ");
        String isPercentage = scanner.nextLine().toUpperCase();

        boolean success = salaryService.addSalaryComponent(empId, componentType, componentName, amount, isPercentage);
        if (success) {
            System.out.println("Salary component added successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void viewSalaryComponents() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        List<SalaryComponent> components = salaryService.getEmployeeSalaryComponents(empId);

        if (components == null || components.isEmpty()) {
            System.out.println("No salary components found!");
            return;
        }

        System.out.println("\n=== SALARY COMPONENTS ===");
        System.out.println("Type\t\tName\t\tAmount");
        System.out.println("------------------------------------");

        for (SalaryComponent component : components) {
            String amountStr = component.getAmount() + ("Y".equals(component.getIsPercentage()) ? "%" : "");
            System.out.printf("%s\t%s\t\t%s\n",
                    component.getComponentType(),
                    component.getComponentName(),
                    amountStr
            );
        }
        pressAnyKeyToContinue();
    }

    private static void calculateSalary() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        Employee employee = employeeService.getEmployee(empId);
        if (employee == null) {
            System.out.println("Employee not found!");
            pressAnyKeyToContinue();
            return;
        }

        SalaryService.SalaryCalculation calculation = salaryService.calculateSalary(empId, employee.getBasicSalary());

        if (calculation != null) {
            System.out.println("\n=== SALARY CALCULATION ===");
            System.out.println("Basic Salary: " + calculation.getBasicSalary());
            System.out.println("Allowances: " + calculation.getTotalAllowances());
            System.out.println("Deductions: " + calculation.getTotalDeductions());
            System.out.println("Gross Salary: " + calculation.getGrossSalary());
            System.out.println("Net Salary: " + calculation.getNetSalary());
        }
        pressAnyKeyToContinue();
    }

    // ==================== PAYROLL MANAGEMENT METHODS ====================

    private static void generatePayrollSingle() {
        System.out.println("\n=== GENERATE PAYROLL ===");

        System.out.print("Employee ID: ");
        int empId = getIntInput();

        System.out.println("Enter Pay Period:");
        System.out.println("Start Date:");
        Date startDate = getDateInput();
        System.out.println("End Date:");
        Date endDate = getDateInput();

        boolean success = payrollService.generatePayroll(empId, startDate, endDate);
        if (success) {
            System.out.println("Payroll generated successfully!");
        }
        pressAnyKeyToContinue();
    }

    private static void generateBulkPayroll() {
        System.out.println("\n=== GENERATE BULK PAYROLL ===");

        System.out.println("Enter Pay Period:");
        System.out.println("Start Date:");
        Date startDate = getDateInput();
        System.out.println("End Date:");
        Date endDate = getDateInput();

        boolean success = payrollService.generateBulkPayroll(startDate, endDate);
        if (success) {
            System.out.println("Bulk payroll generation completed!");
        }
        pressAnyKeyToContinue();
    }

    private static void viewEmployeePayroll() {
        System.out.print("Enter Employee ID: ");
        int empId = getIntInput();

        List<Payroll> payrolls = payrollService.getEmployeePayroll(empId);

        if (payrolls == null || payrolls.isEmpty()) {
            System.out.println("No payroll records found!");
            return;
        }

        System.out.println("\n=== PAYROLL RECORDS ===");
        System.out.println("ID\tPeriod\t\t\tBasic Salary\tNet Salary\tStatus");
        System.out.println("----------------------------------------------------------------");

        for (Payroll payroll : payrolls) {
            String period = dateFormat.format(payroll.getPayPeriodStart()) + " to " + dateFormat.format(payroll.getPayPeriodEnd());
            System.out.printf("%d\t%-20s\t%.2f\t\t%.2f\t%s\n",
                    payroll.getPayrollId(),
                    period,
                    payroll.getBasicSalary(),
                    payroll.getNetSalary(),
                    payroll.getStatus()
            );
        }
        pressAnyKeyToContinue();
    }

    private static void viewPayrollSummary() {
        System.out.println("Enter Date Range for Report:");
        System.out.println("Start Date:");
        Date startDate = getDateInput();
        System.out.println("End Date:");
        Date endDate = getDateInput();

        payrollService.printPayrollSummary(startDate, endDate);
        pressAnyKeyToContinue();
    }

    private static void markPayrollAsPaid() {
        System.out.print("Enter Payroll ID: ");
        int payrollId = getIntInput();

        boolean success = payrollService.markPayrollAsPaid(payrollId);
        if (success) {
            System.out.println("Payroll marked as paid!");
        }
        pressAnyKeyToContinue();
    }

    private static void viewSalaryExpenditure() {
        System.out.println("Enter Date Range:");
        System.out.println("Start Date:");
        Date startDate = getDateInput();
        System.out.println("End Date:");
        Date endDate = getDateInput();

        double expenditure = payrollService.getTotalSalaryExpenditure(startDate, endDate);
        System.out.println("\nTotal Salary Expenditure: " + expenditure);
        pressAnyKeyToContinue();
    }

    // ==================== UTILITY METHODS ====================

    private static int getIntInput() {
        while (true) {
            try {
                return Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a valid number: ");
            }
        }
    }

    private static double getDoubleInput() {
        while (true) {
            try {
                return Double.parseDouble(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.print("Invalid input! Please enter a valid amount: ");
            }
        }
    }

    private static Date getDateInput() {
        while (true) {
            try {
                System.out.print("Enter date (yyyy-MM-dd): ");
                String dateStr = scanner.nextLine();
                return dateFormat.parse(dateStr);
            } catch (ParseException e) {
                System.out.println("Invalid date format! Please use yyyy-MM-dd.");
            }
        }
    }

    private static void pressAnyKeyToContinue() {
        System.out.println("\nPress Enter to continue...");
        scanner.nextLine();
        clearScreen();

        // Show header again
        System.out.println("================================================");
        System.out.println("        EMPLOYEE PAYROLL SYSTEM           ");
        System.out.println("================================================");
    }
}
package dao.impl;

import dao.SalaryComponentDAO;
import model.SalaryComponent;
import util.DataBaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalaryComponentDAOImpl implements  SalaryComponentDAO {

    @Override
    public boolean addSalaryComponent(SalaryComponent component) {
        String sql = "INSERT INTO salary_components (emp_id, component_type, component_name, amount, is_percentage) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, component.getEmpId());
            ps.setString(2, component.getComponentType());
            ps.setString(3, component.getComponentName());
            ps.setDouble(4, component.getAmount());
            ps.setString(5, component.getIsPercentage());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error adding salary component: " + e.getMessage());
            return false;
        }
    }

    @Override
    public List<SalaryComponent> getComponentsByEmployee(int empId) {
        List<SalaryComponent> components = new ArrayList<>();
        String sql = "SELECT * FROM salary_components WHERE emp_id = ? ORDER BY component_type, component_id";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                SalaryComponent component = new SalaryComponent();
                component.setComponentId(rs.getInt("component_id"));
                component.setEmpId(rs.getInt("emp_id"));
                component.setComponentType(rs.getString("component_type"));
                component.setComponentName(rs.getString("component_name"));
                component.setAmount(rs.getDouble("amount"));
                component.setIsPercentage(rs.getString("is_percentage"));

                components.add(component);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting components by employee: " + e.getMessage());
        }

        return components;
    }

    @Override
    public List<SalaryComponent> getAllowancesByEmployee(int empId) {
        List<SalaryComponent> allowances = new ArrayList<>();
        String sql = "SELECT * FROM salary_components WHERE emp_id = ? AND component_type = 'ALLOWANCE' ORDER BY component_id";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                SalaryComponent component = new SalaryComponent();
                component.setComponentId(rs.getInt("component_id"));
                component.setEmpId(rs.getInt("emp_id"));
                component.setComponentType(rs.getString("component_type"));
                component.setComponentName(rs.getString("component_name"));
                component.setAmount(rs.getDouble("amount"));
                component.setIsPercentage(rs.getString("is_percentage"));

                allowances.add(component);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting allowances by employee: " + e.getMessage());
        }

        return allowances;
    }

    @Override
    public List<SalaryComponent> getDeductionsByEmployee(int empId) {
        List<SalaryComponent> deductions = new ArrayList<>();
        String sql = "SELECT * FROM salary_components WHERE emp_id = ? AND component_type = 'DEDUCTION' ORDER BY component_id";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                SalaryComponent component = new SalaryComponent();
                component.setComponentId(rs.getInt("component_id"));
                component.setEmpId(rs.getInt("emp_id"));
                component.setComponentType(rs.getString("component_type"));
                component.setComponentName(rs.getString("component_name"));
                component.setAmount(rs.getDouble("amount"));
                component.setIsPercentage(rs.getString("is_percentage"));

                deductions.add(component);
            }

        } catch (SQLException e) {
            System.err.println("❌ Error getting deductions by employee: " + e.getMessage());
        }

        return deductions;
    }

    @Override
    public boolean updateSalaryComponent(SalaryComponent component) {
        String sql = "UPDATE salary_components SET component_name = ?, amount = ?, is_percentage = ? WHERE component_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, component.getComponentName());
            ps.setDouble(2, component.getAmount());
            ps.setString(3, component.getIsPercentage());
            ps.setInt(4, component.getComponentId());

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating salary component: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteSalaryComponent(int componentId) {
        String sql = "DELETE FROM salary_components WHERE component_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, componentId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error deleting salary component: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteComponentbyEmployee(int empId) {
        String sql = "DELETE FROM salary_components WHERE component_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {


            ps.setInt(1, empId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error deleting salary component: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteComponentsByEmployee(int empId) {
        String sql = "DELETE FROM salary_components WHERE emp_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, empId);
            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error deleting components by employee: " + e.getMessage());
            return false;
        }
    }
}

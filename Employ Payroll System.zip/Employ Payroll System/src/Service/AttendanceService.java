package Service;

import dao.AttendenceDAO;
import dao.EmployeeDAO;
import dao.impl.AttendenceDAOImpl;
import dao.impl.EmployeeDAOImpl;
import model.Attendence;

import java.util.Date;
import java.util.List;

public class AttendanceService {
    private AttendenceDAO attendanceDAO;
    private EmployeeDAO employeeDAO;

    public AttendanceService() {
        this.attendanceDAO = new AttendenceDAOImpl();
        this.employeeDAO = new EmployeeDAOImpl();
    }

    public boolean markAttendance(int empId, String status, double hoursWorked, double overtimeHours) {
        // Validation
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return false;
        }

        if (!employeeDAO.isEmployeeActive(empId)) {
            System.out.println("❌ Error: Employee is not active!");
            return false;
        }

        if (!status.equals("PRESENT") && !status.equals("ABSENT") && !status.equals("HALF_DAY")) {
            System.out.println("❌ Error: Status must be PRESENT, ABSENT, or HALF_DAY!");
            return false;
        }

        if (hoursWorked < 0 || hoursWorked > 24) {
            System.out.println("❌ Error: Hours worked must be between 0 and 24!");
            return false;
        }

        if (overtimeHours < 0) {
            System.out.println("❌ Error: Overtime hours cannot be negative!");
            return false;
        }

        Attendence attendance = new Attendence(empId, status, hoursWorked, overtimeHours);
        boolean success = attendanceDAO.addAttendance(attendance);

        if (success) {
            System.out.println("✅ Attendance marked successfully!");
        } else {
            System.out.println("❌ Failed to mark attendance!");
        }

        return success;
    }

    public List<Attendence> getEmployeeAttendance(int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        return attendanceDAO.getAttendanceByEmployee(empId);
    }

    public List<Attendence> getAttendanceByDateRange(int empId, Date startDate, Date endDate) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        return attendanceDAO.getAttendanceByDateRange(empId, startDate, endDate);
    }

    public AttendanceSummary getAttendanceSummary(int empId, Date startDate, Date endDate) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        int presentDays = attendanceDAO.getPresentDays(empId, startDate, endDate);
        int absentDays = attendanceDAO.getAbsentDays(empId, startDate, endDate);
        double totalOvertime = attendanceDAO.getTotalOvertimeHours(empId, startDate, endDate);

        return new AttendanceSummary(presentDays, absentDays, totalOvertime);
    }

    public boolean updateAttendance(int attendanceId, String status, double hoursWorked, double overtimeHours) {
        // Similar validation as markAttendance
        Attendence attendance = new Attendence();
        attendance.setAttendanceId(attendanceId);
        attendance.setStatus(status);
        attendance.setHoursWorked(hoursWorked);
        attendance.setOvertimeHours(overtimeHours);

        boolean success = attendanceDAO.updateAttendance(attendance);
        if (success) {
            System.out.println("✅ Attendance updated successfully!");
        } else {
            System.out.println("❌ Failed to update attendance!");
        }

        return success;
    }

    // Helper class for attendance summary
    public static class AttendanceSummary {
        private int presentDays;
        private int absentDays;
        private double totalOvertime;

        public AttendanceSummary(int presentDays, int absentDays, double totalOvertime) {
            this.presentDays = presentDays;
            this.absentDays = absentDays;
            this.totalOvertime = totalOvertime;
        }

        // Getters
        public int getPresentDays() { return presentDays; }
        public int getAbsentDays() { return absentDays; }
        public double getTotalOvertime() { return totalOvertime; }

        @Override
        public String toString() {
            return String.format("Present: %d days, Absent: %d days, Overtime: %.1f hours",
                    presentDays, absentDays, totalOvertime);
        }
    }

    public void printAttendanceRecord(Attendence attendance) {
        if (attendance != null) {
            System.out.println("\n📅 ATTENDANCE RECORD:");
            System.out.println("┌─────────────────────────────────────────────────────");
            System.out.println("│ ID: " + attendance.getAttendanceId());
            System.out.println("│ Employee ID: " + attendance.getEmpId());
            System.out.println("│ Date: " + attendance.getAttendanceDate());
            System.out.println("│ Status: " + attendance.getStatus());
            System.out.println("│ Hours Worked: " + attendance.getHoursWorked());
            System.out.println("│ Overtime Hours: " + attendance.getOvertimeHours());
            System.out.println("└─────────────────────────────────────────────────────");
        }
    }
}
package dao.impl;

 import dao.EmployeeDAO;
 import model.Employee;
 import util.DataBaseConnection;

 import java.sql.*;
 import java.util.ArrayList;
 import java.util.List;

public  class EmployeeDAOImpl implements EmployeeDAO {


    @Override
    public boolean addEmployee(Employee employee) {
        String sql = " INSERT INTO employees (name, email, phone, address, job_title, basic_salary, dept_Id, bank_account)" +
                " values (?,?,?,?,?,?,?,?)";

        try (Connection connection = DataBaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1,employee.getName());
            ps.setString(2, employee.getEmail());
            ps.setString(3, employee.getPhone());
            ps.setString(4, employee.getAddress());
            ps.setString(5,employee.getJobtitle());
            ps.setDouble(6,employee.getBasicSalary());
            ps.setInt(7,employee.getDeptId());
            ps.setString(8, employee.getBankAccount());

            int rowsAffected = ps.executeUpdate();
            return  rowsAffected > 0;
        }  catch (SQLException e)
        {
            System.err.print("Error adding employee :-" +e.getMessage());
            return false;
        }
    }

    @Override
    public Employee getEmployeeByID(int empId) {
        String sql = "select * from employees where emp_id = ?";
        Employee employee = null;

        try (Connection connection= DataBaseConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1,empId);
            ResultSet rs= ps.executeQuery();

            if (rs.next()) {
                employee = new Employee();
                employee.setEmpId(rs.getInt("emp_id"));
                employee.setName(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setPhone(rs.getString("phone"));
                employee.setAddress(rs.getString("address"));
                employee.setHireDate(rs.getDate("hire_date"));
                employee.setJobtitle(rs.getString("Job_title"));
                employee.setBasicSalary(rs.getDouble("basic_salary"));
                employee.setDeptId(rs.getInt("dept_id"));
                employee.setBankAccount(rs.getString("bank_account"));
                employee.setStatus(rs.getString("status"));
            }

        } catch (SQLException e)
        {
            System.err.print("error getting employee :-" + e.getMessage());
        }
        return employee;
    }


    @Override
    public Employee getEmployeeByEmail(String email) {
        String sql = "select * from employees where email = ?";
        Employee employee = null;

        try (Connection connection= DataBaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setString(1,email);
            ResultSet rs= ps.executeQuery();

            if (rs.next()) {
                employee = new Employee();
                employee.setEmpId(rs.getInt("emp_id"));
                employee.setName(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setPhone(rs.getString("phone"));
                employee.setAddress(rs.getString("address"));
                employee.setHireDate(rs.getDate("hire_date"));
                employee.setJobtitle(rs.getString("Job_title"));
                employee.setBasicSalary(rs.getDouble("basic_salary"));
                employee.setDeptId(rs.getInt("dept_id"));
                employee.setBankAccount(rs.getString("bank_account"));
                employee.setStatus(rs.getString("status"));
            }

        } catch (SQLException e)
        {
            System.err.print("error getting employee by email:-" + e.getMessage());
        }
        return employee;
    }



    @Override
    public List<Employee> getAllEmployee() {
        List<Employee> employees = new ArrayList<>();
        String sql = "select * from employees ORDER BY emp_id";

        try (Connection connection= DataBaseConnection.getConnection();
             Statement st = connection.createStatement();
             ResultSet rs = st.executeQuery(sql)) {


            while (rs.next()) {
               Employee employee = new Employee();
                employee.setEmpId(rs.getInt("emp_id"));
                employee.setName(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setPhone(rs.getString("phone"));
                employee.setAddress(rs.getString("address"));
                employee.setHireDate(rs.getDate("hire_date"));
                employee.setJobtitle(rs.getString("Job_title"));
                employee.setBasicSalary(rs.getDouble("basic_salary"));
                employee.setDeptId(rs.getInt("dept_id"));
                employee.setBankAccount(rs.getString("bank_account"));
                employee.setStatus(rs.getString("status"));

                employees.add(employee);
            }

        } catch (SQLException e)
        {
            System.err.print("error getting all employees :-" + e.getMessage());
        }
        return employees;
    }

    @Override
    public List<Employee> getEmployeeByDepartment(int deptId) {
        List<Employee> employees = new ArrayList<>();
        String sql = "select * from employees where dept_id = ? order by emp_id";

        try (Connection connection= DataBaseConnection.getConnection();
          PreparedStatement ps= connection.prepareStatement(sql)) {

            ps.setInt(1,deptId);
            ResultSet rs= ps.executeQuery();

            while (rs.next()) {
                Employee employee = new Employee();
                employee.setEmpId(rs.getInt("emp_id"));
                employee.setName(rs.getString("name"));
                employee.setEmail(rs.getString("email"));
                employee.setPhone(rs.getString("phone"));
                employee.setAddress(rs.getString("address"));
                employee.setHireDate(rs.getDate("hire_date"));
                employee.setJobtitle(rs.getString("Job_title"));
                employee.setBasicSalary(rs.getDouble("basic_salary"));
                employee.setDeptId(rs.getInt("dept_id"));
                employee.setBankAccount(rs.getString("bank_account"));
                employee.setStatus(rs.getString("status"));

                employees.add(employee);
            }

        } catch (SQLException e)
        {
            System.err.print("error getting  employees by department:-" + e.getMessage());
        }
        return employees;
    }

    @Override
    public boolean updateEmployee(Employee employee) {
        String sql =" update employees set name = ?, phone =?, address= ? , job_title =?, dept_id = ?," +
                "bank_account= ? where emp_id = ?";

        try (Connection connection = DataBaseConnection.getConnection();
        PreparedStatement ps= connection.prepareStatement(sql)) {

            ps.setString(1, employee.getName());
            ps.setString(2, employee.getPhone());
            ps.setString(3, employee.getAddress());
            ps.setString(4,employee.getJobtitle());
            ps.setInt(5,employee.getDeptId());
            ps.setString(6, employee.getBankAccount());
            ps.setInt(7,employee.getEmpId());

            int rowsAffected = ps.executeUpdate();
            return  rowsAffected > 0;

        }  catch (SQLException e)
        {
            System.err.print("Error updating employees :-" +e.getMessage());
            return false;
        }
    }




    @Override
    public boolean updateEmployeeSalary(int empId, double newSalary) {
        String sql = "UPDATE employees SET basic_salary = ? WHERE emp_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, newSalary);
            ps.setInt(2, empId);

            int rowsAffected = ps.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("❌ Error updating employees salary: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean deleteEmployee(int empId) {
        String sql = "UPDATE employees set status = 'INACTIVE' WHERE emp_id = ?";

        try(Connection connection = DataBaseConnection.getConnection();
        PreparedStatement ps = connection.prepareStatement(sql)) {

            ps.setInt(1,empId);
            int rowsAffected= ps.executeUpdate();
            return rowsAffected >0;
        }catch (SQLException e) {
            System.err.print("error deleting employee:- " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean employeeExists(int empId) {
        String sql = "SELECT * FROM employees WHERE emp_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            ResultSet rs = pstmt.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            System.err.println("❌ Error checking employee existence: " + e.getMessage());
            return false;
        }
    }

    @Override
    public boolean isEmployeeActive(int empId) {
        String sql = "SELECT status FROM employees WHERE emp_id = ?";

        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, empId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return "ACTIVE".equalsIgnoreCase(rs.getString("status"));
            }

        } catch (SQLException e) {
            System.err.println("❌ Error checking employee status: " + e.getMessage());
        }

        return false;
    }
}


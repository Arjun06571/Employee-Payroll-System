package Service;

import dao.DepartmentDAO;
import dao.EmployeeDAO;
import dao.impl.DepartmentDAOImpl;
import dao.impl.EmployeeDAOImpl;
import model.Department;
import model.Employee;

import java.util.List;

public class DepartmentService {
    private DepartmentDAO departmentDAO;
    private EmployeeDAO employeeDAO;

    public DepartmentService() {
        this.departmentDAO = new DepartmentDAOImpl();
        this.employeeDAO = new EmployeeDAOImpl();
    }

    public boolean createDepartment(String deptName, Integer managerId) {
        if (deptName == null || deptName.trim().isEmpty()) {
            System.out.println("Error: Department name cannot be empty!");
            return false;
        }

         // Department object create karo
        Department department = new Department(deptName, managerId);

        // ✅ dept_id set mat karo - database automatically generate karega
        boolean success = departmentDAO.addDepartment(department);

        if (success) {
            System.out.println("Department created successfully!");
        } else {
            System.out.println("Failed to create department!");
        }

        return success;
    }

    public Department getDepartment(int deptId) {
        Department department = departmentDAO.getDepartmentById(deptId);
        if (department == null) {
            System.out.println("❌ Department not found with ID: " + deptId);
        }
        return department;
    }

    public List<Department> getAllDepartments() {
        return departmentDAO.getAllDepartment();
    }

    public boolean updateDepartment(int deptId, String deptName, Integer managerId) {
        Department department = departmentDAO.getDepartmentById(deptId);
        if (department == null) {
            System.out.println("❌ Department not found!");
            return false;
        }

        // Check if manager exists (if provided)
        if (managerId != null && !employeeDAO.employeeExists(managerId)) {
            System.out.println("❌ Error: Manager employee does not exist!");
            return false;
        }

        department.setDeptName(deptName);
        department.setManagerId(managerId);

        boolean success = departmentDAO.updateDepartment(department);
        if (success) {
            System.out.println("✅ Department updated successfully!");
        } else {
            System.out.println("❌ Failed to update department!");
        }

        return success;
    }

    public boolean updateDepartmentManager(int deptId, int managerId) {
        if (!employeeDAO.employeeExists(managerId)) {
            System.out.println("❌ Error: Manager employee does not exist!");
            return false;
        }

        boolean success = departmentDAO.updateDepartmentManager(deptId, managerId);
        if (success) {
            System.out.println("✅ Department manager updated successfully!");
        } else {
            System.out.println("❌ Failed to update department manager!");
        }

        return success;
    }

    public boolean deleteDepartment(int deptId) {
        // Check if department has employees
        List<Employee> employees = employeeDAO.getEmployeeByDepartment(deptId);
        if (!employees.isEmpty()) {
            System.out.println("❌ Cannot delete department with " + employees.size() + " employees!");
            System.out.println("💡 Please reassign or remove employees first.");
            return false;
        }

        boolean success = departmentDAO.deleteDepartment(deptId);
        if (success) {
            System.out.println("✅ Department deleted successfully!");
        } else {
            System.out.println("❌ Failed to delete department!");
        }

        return success;
    }

    public void printDepartmentDetails(Department department) {
        if (department != null) {
            System.out.println("\n🏢 DEPARTMENT DETAILS:");
            System.out.println("┌─────────────────────────────────────────────────────");
            System.out.println("│ ID: " + department.getDeptId());
            System.out.println("│ Name: " + department.getDeptName());
            System.out.println("│ Manager ID: " +
                    (department.getManagerId() != null ? department.getManagerId() : "Not Assigned"));
            System.out.println("└─────────────────────────────────────────────────────");
        }
    }
}
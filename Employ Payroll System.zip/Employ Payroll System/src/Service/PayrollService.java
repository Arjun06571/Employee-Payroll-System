package Service;

import dao.PayrollDAO;
import dao.EmployeeDAO;
import dao.AttendenceDAO;
import dao.SalaryComponentDAO;
import dao.impl.PayrollDAOImpl;
import dao.impl.EmployeeDAOImpl;
import dao.impl.AttendenceDAOImpl;
import dao.impl.SalaryComponentDAOImpl;
import model.Payroll;
import model.Employee;
import model.Attendence;

import java.util.*;
import java.text.SimpleDateFormat;

public class PayrollService {
    private PayrollDAO payrollDAO;
    private EmployeeDAO employeeDAO;
    private AttendenceDAO attendanceDAO;
    private SalaryComponentDAO salaryComponentDAO;
    private SalaryService salaryService;

    public PayrollService() {
        this.payrollDAO = new PayrollDAOImpl();
        this.employeeDAO = new EmployeeDAOImpl();
        this.attendanceDAO = new AttendenceDAOImpl();
        this.salaryComponentDAO = new SalaryComponentDAOImpl();
        this.salaryService = new SalaryService();
    }

    // Generate payroll for a single employee
    public boolean generatePayroll(int empId, Date payPeriodStart, Date payPeriodEnd) {
        // Validation
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return false;
        }

        if (!employeeDAO.isEmployeeActive(empId)) {
            System.out.println("❌ Error: Employee is not active!");
            return false;
        }

        // Check if payroll already exists for this period
        Payroll existingPayroll = payrollDAO.getPayrollByEmployeeAndPeriod(empId, payPeriodStart, payPeriodEnd);
        if (existingPayroll != null) {
            System.out.println("❌ Payroll already generated for this period!");
            return false;
        }

        // Get employee details
        Employee employee = employeeDAO.getEmployeeByID(empId);
        double basicSalary = employee.getBasicSalary();

        // Calculate salary components
        SalaryService.SalaryCalculation salaryCalc = salaryService.calculateSalary(empId, basicSalary);

        // Calculate overtime pay (assuming ₹200 per overtime hour)
        double totalOvertimeHours = attendanceDAO.getTotalOvertimeHours(empId, payPeriodStart, payPeriodEnd);
        double overtimePay = totalOvertimeHours * 200; // ₹200 per overtime hour

        // Calculate net salary with overtime
        double netSalary = salaryCalc.getNetSalary() + overtimePay;

        // Create payroll record
        Payroll payroll = new Payroll(empId, payPeriodStart, payPeriodEnd, basicSalary);
        payroll.setAllowances(salaryCalc.getTotalAllowances());
        payroll.setDeductions(salaryCalc.getTotalDeductions());
        payroll.setOverTimePay(overtimePay);
        payroll.setNetSalary(netSalary);
        payroll.setStatus("PROCESSED");

        boolean success = payrollDAO.addPayroll(payroll);

        if (success) {
            System.out.println("✅ Payroll generated successfully!");
            printPayrollSlip(payroll, employee);
        } else {
            System.out.println("❌ Failed to generate payroll!");
        }

        return success;
    }

    // Generate payroll for all active employees
    public boolean generateBulkPayroll(Date payPeriodStart, Date payPeriodEnd) {
        List<Employee> activeEmployees = employeeDAO.getAllEmployee();
        int successCount = 0;
        int totalCount = 0;

        System.out.println("\n🔄 Generating payroll for all active employees...");

        for (Employee employee : activeEmployees) {
            if ("ACTIVE".equals(employee.getStatus())) {
                totalCount++;
                boolean success = generatePayroll(employee.getEmpId(), payPeriodStart, payPeriodEnd);
                if (success) {
                    successCount++;
                }
            }
        }

        System.out.println("✅ Payroll generation completed!");
        System.out.println("📊 Successfully generated: " + successCount + "/" + totalCount + " payroll records");

        return successCount > 0;
    }

    // Calculate salary with attendance considerations
    public SalaryService.SalaryCalculation calculateSalaryWithAttendance(int empId, Date startDate, Date endDate) {
        Employee employee = employeeDAO.getEmployeeByID(empId);
        if (employee == null) {
            return null;
        }

        double basicSalary = employee.getBasicSalary();

        // Get attendance summary
        AttendanceService attendanceService = new AttendanceService();
        AttendanceService.AttendanceSummary summary = attendanceService.getAttendanceSummary(empId, startDate, endDate);

        // Calculate working days (assuming 22 working days in a month)
        int totalWorkingDays = 22;
        int actualWorkingDays = summary.getPresentDays();

        // Adjust basic salary based on attendance
        double adjustedBasicSalary = basicSalary * (actualWorkingDays / (double) totalWorkingDays);

        // Calculate salary with adjusted basic
        return salaryService.calculateSalary(empId, adjustedBasicSalary);
    }

    // Get payroll by ID
    public Payroll getPayroll(int payrollId) {
        Payroll payroll = payrollDAO.getPayrollById(payrollId);
        if (payroll == null) {
            System.out.println("❌ Payroll not found with ID: " + payrollId);
        }
        return payroll;
    }

    // Get payroll for employee
    public List<Payroll> getEmployeePayroll(int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Employee does not exist!");
            return null;
        }

        return payrollDAO.getPayrollByEmployee(empId);
    }

    // Get payroll by date range
    public List<Payroll> getPayrollByDateRange(Date startDate, Date endDate) {
        return payrollDAO.getPayrollByDateRange(startDate, endDate);
    }

    // Update payroll status
    public boolean updatePayrollStatus(int payrollId, String status) {
        if (!status.equals("PENDING") && !status.equals("PROCESSED") && !status.equals("PAID")) {
            System.out.println("❌ Error: Status must be PENDING, PROCESSED, or PAID!");
            return false;
        }

        boolean success = payrollDAO.updatePayrollStatus(payrollId, status);
        if (success) {
            System.out.println("✅ Payroll status updated successfully!");
        } else {
            System.out.println("❌ Failed to update payroll status!");
        }

        return success;
    }

    // Mark payroll as paid
    public boolean markPayrollAsPaid(int payrollId) {
        return updatePayrollStatus(payrollId, "PAID");
    }

    // Get total salary expenditure for period
    public double getTotalSalaryExpenditure(Date startDate, Date endDate) {
        return payrollDAO.getTotalSalaryExpenditure(startDate, endDate);
    }

    // Print payroll slip
    public void printPayrollSlip(Payroll payroll, Employee employee) {
        if (payroll != null && employee != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

            System.out.println("\n🧾 PAYROLL SLIP");
            System.out.println("┌─────────────────────────────────────────────────────────");
            System.out.println("│ Employee: " + employee.getName() + " (" + employee.getEmpId() + ")");
            System.out.println("│ Period: " + dateFormat.format(payroll.getPayPeriodStart()) + " to " +
                    dateFormat.format(payroll.getPayPeriodEnd()));
            System.out.println("│ Job Title: " + employee.getJobtitle());
            System.out.println("├─────────────────────────────────────────────────────────");
            System.out.println("│ EARNINGS:");
            System.out.println("│   Basic Salary:      ₹" + String.format("%,.2f", payroll.getBasicSalary()));
            System.out.println("│   Allowances:        ₹" + String.format("%,.2f", payroll.getAllowances()));
            System.out.println("│   Overtime Pay:      ₹" + String.format("%,.2f", payroll.getOverTimePay()));
            System.out.println("├─────────────────────────────────────────────────────────");
            System.out.println("│ DEDUCTIONS:");
            System.out.println("│   Total Deductions:  ₹" + String.format("%,.2f", payroll.getDeductions()));
            System.out.println("├─────────────────────────────────────────────────────────");
            System.out.println("│ NET SALARY:          ₹" + String.format("%,.2f", payroll.getNetSalary()));
            System.out.println("│ Status: " + payroll.getStatus());
            System.out.println("│ Bank Account: " + employee.getBankAccount());
            System.out.println("│ Generated: " + dateFormat.format(payroll.getGenratedDate()));
            System.out.println("└─────────────────────────────────────────────────────────");
        }
    }

    // Print payroll summary report
    public void printPayrollSummary(Date startDate, Date endDate) {
        List<Payroll> payrolls = getPayrollByDateRange(startDate, endDate);
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yyyy");

        System.out.println("\n📊 PAYROLL SUMMARY REPORT");
        System.out.println("Period: " + dateFormat.format(startDate) + " to " + dateFormat.format(endDate));
        System.out.println("┌───────┬──────────────────┬──────────────┬──────────────┬──────────────┐");
        System.out.println("│ ID    │ Employee         │ Basic Salary │ Deductions   │ Net Salary   │");
        System.out.println("├───────┼──────────────────┼──────────────┼──────────────┼──────────────┤");

        double totalBasic = 0;
        double totalDeductions = 0;
        double totalNet = 0;

        for (Payroll payroll : payrolls) {
            Employee employee = employeeDAO.getEmployeeByID(payroll.getEmpId());
            String empName = employee != null ? employee.getName() : "N/A";

            System.out.printf("│ %-5d │ %-16s │ %-12.2f │ %-12.2f │ %-12.2f │\n",
                    payroll.getPayrollId(),
                    empName.length() > 16 ? empName.substring(0, 13) + "..." : empName,
                    payroll.getBasicSalary(),
                    payroll.getDeductions(),
                    payroll.getNetSalary());

            totalBasic += payroll.getBasicSalary();
            totalDeductions += payroll.getDeductions();
            totalNet += payroll.getNetSalary();
        }

        System.out.println("├───────┼──────────────────┼──────────────┼──────────────┼──────────────┤");
        System.out.printf("│ %-5s │ %-16s │ %-12.2f │ %-12.2f │ %-12.2f │\n",
                "TOTAL", "", totalBasic, totalDeductions, totalNet);
        System.out.println("└───────┴──────────────────┴──────────────┴──────────────┴──────────────┘");
    }

    // Utility method to get date for payroll period
    public Date[] getCurrentMonthPeriod() {
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        Date startDate = cal.getTime();

        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date endDate = cal.getTime();

        return new Date[]{startDate, endDate};
    }

    // Utility method to get previous month period
    public Date[] getPreviousMonthPeriod() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -1);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        Date startDate = cal.getTime();

        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
        Date endDate = cal.getTime();

        return new Date[]{startDate, endDate};
    }
}
package dao;

import model.SalaryComponent;
import java.util.List;

public interface SalaryComponentDAO
{
    //Create
    boolean addSalaryComponent(SalaryComponent component);

    // Read
    List<SalaryComponent> getComponentsByEmployee(int empId);
    List<SalaryComponent> getAllowancesByEmployee(int empId);
    List<SalaryComponent> getDeductionsByEmployee(int empId);

    // update
    boolean updateSalaryComponent(SalaryComponent component);

     // delete
    boolean deleteSalaryComponent(int componentId);
    boolean deleteComponentbyEmployee(int empId);

    boolean deleteComponentsByEmployee(int empId);
}

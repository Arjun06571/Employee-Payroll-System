package dao;

import model.Employee;
import  java.util.List;

public interface EmployeeDAO
{

    // create
    boolean addEmployee(Employee employee);

    // Read
    Employee getEmployeeByID(int empId);
    Employee getEmployeeByEmail(String email);
    List<Employee> getAllEmployee();
    List<Employee> getEmployeeByDepartment(int deptId);
    
    // Update
    boolean updateEmployee(Employee employee);
    boolean updateEmployeeSalary(int empId, double newSalary);


    // Delete
    boolean deleteEmployee(int empId);

    // Validation
    boolean employeeExists(int empId);
    boolean isEmployeeActive(int empId);
}

package Service;

import dao.SalaryComponentDAO;
import dao.EmployeeDAO;
import dao.impl.SalaryComponentDAOImpl;
import dao.impl.EmployeeDAOImpl;
import model.SalaryComponent;

import java.util.List;

public class SalaryService {
    private SalaryComponentDAO salaryComponentDAO;
    private EmployeeDAO employeeDAO;

    public SalaryService() {
        this.salaryComponentDAO = new SalaryComponentDAOImpl();
        this.employeeDAO = new EmployeeDAOImpl();
    }

    public boolean addSalaryComponent(int empId, String componentType, String componentName,
                                      double amount, String isPercentage) {
        // Validation
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return false;
        }

        if (!componentType.equals("ALLOWANCE") && !componentType.equals("DEDUCTION")) {
            System.out.println("❌ Error: Component type must be ALLOWANCE or DEDUCTION!");
            return false;
        }

        if (componentName == null || componentName.trim().isEmpty()) {
            System.out.println("❌ Error: Component name cannot be empty!");
            return false;
        }

        if (amount < 0) {
            System.out.println("❌ Error: Amount cannot be negative!");
            return false;
        }

        if (!isPercentage.equals("Y") && !isPercentage.equals("N")) {
            System.out.println("❌ Error: IsPercentage must be Y or N!");
            return false;
        }

        SalaryComponent component = new SalaryComponent(empId, componentType, componentName, amount, isPercentage);
        boolean success = salaryComponentDAO.addSalaryComponent(component);

        if (success) {
            System.out.println("✅ Salary component added successfully!");
        } else {
            System.out.println("❌ Failed to add salary component!");
        }

        return success;
    }

    public List<SalaryComponent> getEmployeeSalaryComponents(int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        return salaryComponentDAO.getComponentsByEmployee(empId);
    }

    public List<SalaryComponent> getEmployeeAllowances(int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        return salaryComponentDAO.getAllowancesByEmployee(empId);
    }

    public List<SalaryComponent> getEmployeeDeductions(int empId) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        return salaryComponentDAO.getDeductionsByEmployee(empId);
    }

    public SalaryCalculation calculateSalary(int empId, double basicSalary) {
        if (!employeeDAO.employeeExists(empId)) {
            System.out.println("❌ Error: Employee does not exist!");
            return null;
        }

        List<SalaryComponent> allowances = getEmployeeAllowances(empId);
        List<SalaryComponent> deductions = getEmployeeDeductions(empId);

        double totalAllowances = 0;
        double totalDeductions = 0;

        // Calculate allowances
        for (SalaryComponent allowance : allowances) {
            if ("Y".equals(allowance.getIsPercentage())) {
                totalAllowances += basicSalary * (allowance.getAmount() / 100);
            } else {
                totalAllowances += allowance.getAmount();
            }
        }

        // Calculate deductions
        for (SalaryComponent deduction : deductions) {
            if ("Y".equals(deduction.getIsPercentage())) {
                totalDeductions += basicSalary * (deduction.getAmount() / 100);
            } else {
                totalDeductions += deduction.getAmount();
            }
        }

        double grossSalary = basicSalary + totalAllowances;
        double netSalary = grossSalary - totalDeductions;

        return new SalaryCalculation(basicSalary, totalAllowances, totalDeductions, grossSalary, netSalary);
    }

    public boolean updateSalaryComponent(int componentId, String componentName, double amount, String isPercentage) {
        SalaryComponent component = new SalaryComponent();
        component.setComponentId(componentId);
        component.setComponentName(componentName);
        component.setAmount(amount);
        component.setIsPercentage(isPercentage);

        boolean success = salaryComponentDAO.updateSalaryComponent(component);
        if (success) {
            System.out.println("✅ Salary component updated successfully!");
        } else {
            System.out.println("❌ Failed to update salary component!");
        }

        return success;
    }

    public boolean deleteSalaryComponent(int componentId) {
        boolean success = salaryComponentDAO.deleteSalaryComponent(componentId);
        if (success) {
            System.out.println("✅ Salary component deleted successfully!");
        } else {
            System.out.println("❌ Failed to delete salary component!");
        }

        return success;
    }

    // Helper class for salary calculation
    public static class SalaryCalculation {
        private double basicSalary;
        private double totalAllowances;
        private double totalDeductions;
        private double grossSalary;
        private double netSalary;

        public SalaryCalculation(double basicSalary, double totalAllowances, double totalDeductions,
                                 double grossSalary, double netSalary) {
            this.basicSalary = basicSalary;
            this.totalAllowances = totalAllowances;
            this.totalDeductions = totalDeductions;
            this.grossSalary = grossSalary;
            this.netSalary = netSalary;
        }

        // Getters
        public double getBasicSalary() { return basicSalary; }
        public double getTotalAllowances() { return totalAllowances; }
        public double getTotalDeductions() { return totalDeductions; }
        public double getGrossSalary() { return grossSalary; }
        public double getNetSalary() { return netSalary; }

        @Override
        public String toString() {
            return String.format(
                    "Basic Salary: ₹%.2f\n" +
                            "Allowances: ₹%.2f\n" +
                            "Deductions: ₹%.2f\n" +
                            "Gross Salary: ₹%.2f\n" +
                            "Net Salary: ₹%.2f",
                    basicSalary, totalAllowances, totalDeductions, grossSalary, netSalary
            );
        }
    }

    public void printSalaryComponent(SalaryComponent component) {
        if (component != null) {
            System.out.println("\n💰 SALARY COMPONENT:");
            System.out.println("┌─────────────────────────────────────────────────────");
            System.out.println("│ ID: " + component.getComponentId());
            System.out.println("│ Employee ID: " + component.getEmpId());
            System.out.println("│ Type: " + component.getComponentType());
            System.out.println("│ Name: " + component.getComponentName());
            System.out.println("│ Amount: " + component.getAmount() +
                    ("Y".equals(component.getIsPercentage()) ? "%" : "₹"));
            System.out.println("└─────────────────────────────────────────────────────");
        }
    }
}